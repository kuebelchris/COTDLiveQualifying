namespace VMMapper 
{
	array<SingleUserResultVM@> ToSingleUserResultVMs(const array<Result@> &in results)
	{
		array<SingleUserResultVM@> resultVMs = {};
		for(uint n = 0; n < results.Length; n++ )
		{
			Result@ result = results[n];
			SingleUserResultVM@ vm = SingleUserResultVM(result.rank, result.div, result.time, UserManager::GetDisplayNameForAccount(result.accountId), false, false);
			resultVMs.InsertLast(vm);
		}
		return resultVMs;
	}

	SingleUserResultVM@ ToSingleUserResultCutoffVM(const Result &in result)
	{
		return SingleUserResultVM(result.rank, result.div, result.time, "Div 1 Cutoff", false, true);
	}

	SingleUserResultVM@ ToSingleUserResultCutoffPredictionVM(const int &in predictedTime)
	{
		return SingleUserResultVM(0, 1, predictedTime, "Div 1 Cutoff Prediction", true, false);
	}

}